"""DuckDuckGo Search API toolkit."""

from langchain_community.tools.ddg_search.tool import DuckDuckGoSearchRun

__all__ = ["DuckDuckGoSearchRun"]
