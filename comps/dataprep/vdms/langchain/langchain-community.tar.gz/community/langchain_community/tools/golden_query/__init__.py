"""Golden API toolkit."""


from langchain_community.tools.golden_query.tool import GoldenQueryRun

__all__ = [
    "GoldenQueryRun",
]
