from langchain_community.tools.audio.huggingface_text_to_speech_inference import (
    HuggingFaceTextToSpeechModelInference,
)

__all__ = [
    "HuggingFaceTextToSpeechModelInference",
]
