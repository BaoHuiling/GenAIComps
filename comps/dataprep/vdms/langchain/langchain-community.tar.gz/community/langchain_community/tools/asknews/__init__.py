"""AskNews API toolkit."""

from langchain_community.tools.asknews.tool import (
    AskNewsSearch,
)

__all__ = ["AskNewsSearch"]
